package com.oreilly.springdata.hadoop.filepolling;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class FilePolling {

    public static void main(String[] args) throws Exception {
	     AbstractApplicationContext context = 
			new ClassPathXmlApplicationContext("/META-INF/spring/application-context.xml", FilePolling.class);
	
	     context.registerShutdownHook();
	     
    }
}

